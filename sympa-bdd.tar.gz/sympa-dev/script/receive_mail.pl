#!/usr/bin/perl

# O.Salaün, May 2018
# Script to collect mails sent by the functional testing scripts

my $spool = '/opt/sympa-dev/mail_spool';

my $mail_content;
while (<STDIN>) {
    $mail_content .= $_;
}

unless (-d '/opt/sympa-dev/mail_spool') {
    mkdir '/opt/sympa-dev/mail_spool';
}

open MAIL, ">$spool/$$.eml";
print MAIL $mail_content;
close MAIL;
